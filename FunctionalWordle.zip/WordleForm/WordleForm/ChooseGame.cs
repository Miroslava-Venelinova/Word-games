﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace WordleForm
{
    public partial class ChooseGame : Form
    {
        int totalWordleWins = 0;
        int wordleWinstreak = 0;
        int totalWordleGames = 0;
        int totalHangmanWins = 0;
        int hangmanWinstreak = 0;
        int totalHangmanGames = 0;
        public ChooseGame()
        {
            InitializeComponent();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            //SignIn form = new SignIn();
            //form.Show();
            //this.Hide();
            MessageBox.Show("Not implemented sign in");
        }

        private void ChooseGame_Load(object sender, EventArgs e)
        {
            GetScore();
        }

        private void GetScore()
        {
            //IMPLMENT GETTING DATAFROM DATABASE

            /*using (var sw = new StreamReader("../../../Wins.txt"))
            {
                string[] strings = sw.ReadLine().Split(" ").ToArray();
                totalWordleWins = int.Parse(strings[0]);
                wordleWinstreak = int.Parse(strings[1]);
                totalWordleGames = int.Parse(strings[2]);
                totalHangmanWins = int.Parse(strings[3]);
                hangmanWinstreak = int.Parse(strings[4]);
                totalHangmanGames = int.Parse(strings[5]);
            }*/
            label3.Text = "Брой победи: " + totalWordleWins;
            label4.Text = "Поредни победи: " + wordleWinstreak;
            label7.Text = "Общ брой игри: " + totalWordleGames;
            label4.Text = "Брой победи: " + totalHangmanWins;
            label5.Text = "Поредни победи: " + hangmanWinstreak;
            label8.Text = "Общ брой игри: " + totalHangmanGames;
        }

        private void button2_Click(object sender, EventArgs e)
        {
            Wordle form = new Wordle();
            form.Show();
            this.Hide();
        }

        private void button3_Click(object sender, EventArgs e)
        {
            //Hangman form = new Hangman();
            //form.Show();
            //this.Hide();
            MessageBox.Show("Not implemented hangman");
        }
    }
}
